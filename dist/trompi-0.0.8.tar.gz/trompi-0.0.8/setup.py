import setuptools
setuptools.setup(
    name='trompi',
    version='v0.0.8',
    description='import lib from file service',
    py_modules=['trompi'],
    author='chenjianwei',
    author_email='1572069841@qq.com',
    url='https://github.com/JianweiChen/trompi',
    packages=setuptools.find_packages(),
    license='MIT'
)